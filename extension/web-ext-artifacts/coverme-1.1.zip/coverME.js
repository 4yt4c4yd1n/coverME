async function scrape(){
    let jobTitle = document.getElementsByClassName("t-24 t-bold inline")[0].innerText
    let company = document.getElementsByClassName("ember-view link-without-visited-state inline-block t-black")[0].innerText
    let jobDescription = document.getElementById("job-details").innerText
    jobDescription = jobDescription.substring(jobDescription.indexOf("\n") + 1)

    console.log("Scraped")
    promptStr = `Write LaTeX code for a cover letter for the job below. Also import graphicx package. Use everyday language. Job title:  
    ${jobTitle}\n  "company name:  ${company}\n  job description:\n  ${jobDescription}  Here's some info about me. Only mention the most relevant ones:
    I study Computational Engineering Science at TU Berlin.\n
    I am good with Python and Julia and have made experiences with them throught my studies\n
    I know Unity and have made experiences with it for my robot simulation project at uni\n
    I tinker with all kinds of programming in my free time\n
    WRITE IN THE LANGUAGE JOB DESCRIPTION WAS WRITTEN IN
    Don't forget to escape special characters(like #). Only respond with code as plain text without code block syntax around it.
    Insert today's date. If company address is not available, just say Berlin. My name is Aytac Aydin. 
    Don't mention phone number. My email is aydinaytac01@gmail.com. My address is Kantstraße 61, 10627 Berlin
    Before \\end{document} line add this at all costs:
    \\footnote{
    \\begin{center}
    \\includegraphics[width=32px]{ChatGPT-Logo.png}\\\\
    \\scriptsize{Information on this page is correct, but it was generated automatically. For more information visit:}
    \\end{center}
}
`;
    browser.runtime.sendMessage({ trigger: 'promptReady', promptStr });
}

browser.runtime.onMessage.addListener(data => {
    const { trigger } = data;
    if (trigger === 'scrape') scrape();
  });