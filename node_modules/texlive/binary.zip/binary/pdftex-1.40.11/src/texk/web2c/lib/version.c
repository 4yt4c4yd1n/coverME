#include <w2c/c-auto.h>

/* This string is appended to all the banners and used in --version.  */
/* Public domain. */

const char *versionstring = WEB2CVERSION;
